package se.grunka.fortuna.accumulator;

public interface EventAdder {
    void add(byte[] event);
}

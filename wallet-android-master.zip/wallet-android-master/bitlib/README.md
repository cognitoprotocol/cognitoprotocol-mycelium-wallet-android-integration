This library implements the bitcoin protocol. It's to be deprecated with the switch to a modular,
[bitcoinJ](https://bitcoinj.github.io/) based wallet.

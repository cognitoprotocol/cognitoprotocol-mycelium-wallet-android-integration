camera-switcher.svg is original art by Leo Wandersleb, hereby released into the public domain.
